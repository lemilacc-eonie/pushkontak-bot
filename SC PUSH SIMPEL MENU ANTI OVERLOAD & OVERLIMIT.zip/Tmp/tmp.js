/* 

   #### Pushkontak By Skyzopedia #####
   
   Developer: 
   - Skyzopedia (wa.me/6283164464290)
   
   Follow Channel Developer:
   - https://whatsapp.com/channel/0029VbBjJiH6LwHpPjYCZ334
   
   Recode:
   - YT Lexzymarket ( t.me/Lexzymarket )
   
   # Penting
   Jangan hapus credits atau nama developer
   hargai pembuat script ini!

*/